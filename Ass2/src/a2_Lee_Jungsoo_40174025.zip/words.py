import sys
from Guess import Guess

if __name__ == "__main__":
    if len(sys.argv) == 2:
        cmdArg = sys.argv[1].lower()
        if cmdArg == "play" or cmdArg == "test":
            gameStart = Guess()
            gameStart.start(cmdArg)
        else:
            print("Incorrect input values. The game will not start. Please input correct values: \"play\" or \"test\".")
            exit()
    else:
        print("Incorrect input values. The game will not start. Please input correct values: \"play\" or \"test\".")
        exit()