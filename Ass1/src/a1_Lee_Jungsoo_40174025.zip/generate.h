#ifndef GENERATE_DOT_H
#define GENERATE_DOT_H

#include "tablegen.h"

void createRows(struct Package *rows, char colmnNb[], int nbRows);

#endif